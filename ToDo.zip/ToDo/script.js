let count = 0;
function add(e){

    let item = document.getElementById("input").value;
     document.getElementById("input").value = "";

     var p = document.createElement("p");
     p.setAttribute("key", count);
     p.innerText = item;
     p.addEventListener("click", remove);
     count++;
     let div = document.getElementById("todos");
     div.appendChild(p);

}
function remove(e){
    let div=document.getElementById("todos");
    div.removeChild(e.target);  
}